<div class="col-md-8">

    @if(isset($products) )
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>#</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($products as $productId => $product)
                <tr>
                    <td>{{$productId + 1}}</td>
                    <td>{{$product->name}}</td>
                    <td>{{number_format($product->quantity)}}</td>
                    <td> $ {{ $product->price}}</td>
                    <td><a class="btn btn-primary" href='{{ url("/products/$productId/edit") }}'><i class="glyphicon glyphicon-pencil"></i> <small>Edit</small></a>
                    <a class="btn btn-danger" href='{{ url("/products/$productId/delete") }}'><i class="glyphicon glyphicon-trash"></i> <small>Delete</small> </a></td>
                </tr>
            @endforeach
            <tr class="table-success">
                <td colspan="3">Total Value:</tdc>
                <td id="total"> $ {{  $total }}</td>
                <td></td>
            </tr>
            </tbody>
        </table>
    @endif
</div>
@include('flash')
