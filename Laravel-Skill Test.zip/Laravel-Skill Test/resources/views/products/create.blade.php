@extends('layout')

@section('content')
    <h1>Products</h1>
    <h2><span class="label label-{{ $actionClass }}">{{ $actionText }}</span></h2>
    <form id="form-products" method="{{ $method }}" action="{{ $url }}">
        {{ csrf_field() }}
        @include('products.form')
    </form>
@stop

